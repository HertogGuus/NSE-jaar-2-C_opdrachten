#include <stdio.h>
#include <math.h>

void max_of_arrays(double *array_1, double *array_2, double *array_3, double size);
void print_positions( double *array_1, double *array_2);

int main()
{
    double array_1[] = {0.7, 3.3, 0.5, 10.3};
    double array_2[] = {4.1, 1.5, 0.5, 2.3};
    double array_3[4];

    print_positions( array_1, array_2);

    max_of_arrays(array_1,array_2, array_3, 4);

    return 0;
}

void print_positions( double *array_1, double *array_2){
    //pointers en andere benodigde variablen aanmaken
    int i;
    double *j;
    j=array_1;
    double *g;
    g=array_2;

    printf("Array_1 is:");
    for(i=0;i<4;i++){
        printf("[%f", j[i]);
        printf("] ");
    }
    printf("\n");    
    
    printf("Array_2 is:");
    for(i=0;i<4;i++){
        printf("[%f", g[i]);
        printf("] ");
    }
    printf("\n");    

}

void max_of_arrays(double *array_1, double *array_2, double *array_3, double size)
{
    int i; 
    int d;

    double *j;
    j=array_1;
    double *g;
    g=array_2;
    double *v;
    v=array_3;
    


    for (int d = 0; d < size; d++)
    {
        printf("%d",d);
        if (j[d] > g[d]){
            array_3[d]=j[d];
        }
        if (j[d] < g[d]){
            array_3[d]=g[d];
        }
        else{
            array_3[d]=j[d];
        }
        printf("here");

    }
    //Todo maak apparte functie aan die alle 3 arrays print afhankelijk van de ingevoerde variablen.
    printf("Array_3 is:");
    for(i=0;i<4;i++){
        printf("[%f", v[i]);
        printf("] ");
    }

}
