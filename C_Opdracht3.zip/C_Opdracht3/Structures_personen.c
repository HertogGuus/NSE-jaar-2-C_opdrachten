#include <stdio.h>


struct person{

    char name[20];
    int age;
};


int main(){
    struct person Person1;

    printf("Enter Records of a person");
    printf("\nEnter Name:");    

    scanf("%s", Person1.name); 

    printf("\nEnter Age:");    
    
    //Wanneer ik bij de volgende input komt is er automatich een waarde die zo groot blijkt te zijn dat het mijn script crashed.
    //Wanneer ik het weglaat werkt mijn script wel gewoon.
    //scanf("%d", Person1.age);    

    printf("\n");
    printf("Person 1 name %s\n", Person1.name);
    printf("Person 1 age %d\n", Person1.age);
    return 0;
}