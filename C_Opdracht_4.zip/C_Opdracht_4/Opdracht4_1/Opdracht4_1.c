#include <stdio.h>
#include <stdlib.h>

//void function nog fixen
void Lenght(char const *filename);

int main()
{
    FILE *fptr1, *fptr2;
    char filename[100], c;
  
    printf("Enter the filename to open for reading \n");
    scanf("%s", filename);
  
    // Open one file for reading
    fptr1 = fopen(filename, "r");
    if (fptr1 == NULL)
    {
        printf("Cannot open file %s \n", filename);
        exit(0);
    }
  
    printf("Enter the filename to open for writing \n");
    scanf("%s", filename);
  
    // Open another file for writing
    fptr2 = fopen(filename, "w");
    if (fptr2 == NULL)
    {
        printf("Cannot open file %s \n", filename);
        exit(0);
    }
  

    c = fgetc(fptr1);
     while (c != EOF)
    {
        c = c + 1;
        fputc(c, fptr2);
        c = fgetc(fptr1);
    }
  
    printf("\nContents copied to %s", filename);
    printf("\nContent of %s have been ascii shifted by 1",filename);
  
    fclose(fptr1);
    fclose(fptr2);

    //make a function that counts the total lenght of the relevant file.
    Lenght(filename);

    return 0;
}

void Lenght(char const *filename){
  
    FILE* fp;
    int count = 0;

  
    // To store a character read from file
    char c;
  
    // Open one file for reading
    fp = fopen(filename, "r");
    if (fp == NULL)
    {
        printf("Cannot open file %s \n", filename);
        exit(0);
    }
  
    // Extract characters from file
    // and store in character c
    for (c = getc(fp); c != EOF; c = getc(fp))
  
        // Increment count for this character
        count = count + 1;
  
    // Close the file
    fclose(fp);
  
    // Print the count of characters
    printf("\nThe file has a total of %d characters\n ", count);
  
}