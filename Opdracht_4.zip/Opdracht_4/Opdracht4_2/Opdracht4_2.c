#include <stdio.h>
#include <cstdlib>
#include <string.h>
#include <stdbool.h>

typedef struct person
{
    char naam[20];
    int age;
}person;

int main (void){
    int g = 0;
    int size = 1;
    person* persons = (person *)malloc(size*sizeof(struct person));
    char cont;

    while(true){
        printf("Vul hier de persoon gegevens in: \n");
        scanf("%s%d", persons[g].naam, &persons[g].age);
        printf("naam: %s\n leeftijd: %d\n", persons[g].naam, persons[g].age);

        //Print alle ingevoerd informatie
        printf("Print alle persoonsgegevens.\n");
        for (int x = 0; x < size; x++){
        printf("Naam: %s\nLeeftijd: %d\n", persons[x].naam, persons[x].age);
        }

        printf("will je nog een persoon invoeren? [y/n]\n");
        printf("indien van niet zal deze script eindigen.\n");
        scanf(" %c", &cont);   

        if (cont == 'n'){
            //Gebruikte geheugen vrijmaken
            printf("Vrijmaken van geheugen");
            free(persons);
            return 0;
            }

        g++;

        if ( g == size)
        {
            size++;
            persons = (person *)realloc(persons, size*sizeof(persons)); //meer geheugen alloceren aan de persons structure door realloc aan te roepen
            if( !persons)
            {
                printf("Geheugen is op!");
                break;
            }
        }
    }
}