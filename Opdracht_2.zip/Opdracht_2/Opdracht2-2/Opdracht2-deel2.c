    #include<stdio.h>  
      
    void circle_omtrek(float, float*);  
    const int PI = 3.14;
    int main()  
    {  
        float diameter, Omtrek;  
      
        printf("Voer hier de diameter van de Cirkel: ");  
        scanf("%f", &diameter);  
      
        circle_omtrek(diameter, &Omtrek);  
       
        printf("Omtrek van de cirkel = %0.2f\n", Omtrek);  
      
        return 0;  
    }  
      
    void circle_omtrek(float r, float *p)  
    {  
        *p = PI * r;  
    }  