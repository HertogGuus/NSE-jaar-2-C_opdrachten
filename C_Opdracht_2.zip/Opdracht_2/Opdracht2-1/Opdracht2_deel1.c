#include <stdio.h>
#include "Opdracht2.h"


int main() {
    int number;
   
    printf("Er zijn 3 opties in deze spel\n"); 
    printf("Gebruik de volgende 3 opties: optie '1', optie '2' en optie '-3'\n");
    printf("Voor optie '3' gebruik een negatief getal.\n");
    printf("Welke optie neemt u: ");
    scanf("%d", &number);

    if (number == 2) {
      int a = BEERS();
    }
    if (number == 1) {
       printf( "Je koos: %d.\n", number );
    }
    if (number < 0) {
       printf("Foute antwoord");
    }
    
    return 0;

    }

