    #include<stdio.h>  
      
    void circle_omtrek(float*);  
    const float PI = 3.14;

    int main()  
    {  
        float omtrekofdia;  

        printf("Voer hier de diameter van de Cirkel: "); 
        //input van gebruiker krijgen 
        scanf("%f", &omtrekofdia);  

        //roep het functie circle omtrek aan.
        circle_omtrek(&omtrekofdia);  
       
        printf("Omtrek van de cirkel = %f\n", omtrekofdia);  

        return 0;  
    }  
      
    void circle_omtrek(float *omtrekofdia)  
    {  
        *omtrekofdia = PI * *omtrekofdia;  
    }  